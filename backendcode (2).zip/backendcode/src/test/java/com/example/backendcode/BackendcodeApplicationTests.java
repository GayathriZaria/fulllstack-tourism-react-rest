package com.example.backendcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendcodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
