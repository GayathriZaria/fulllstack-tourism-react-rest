package com.example.backendcode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendcodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendcodeApplication.class, args);
	}

}
