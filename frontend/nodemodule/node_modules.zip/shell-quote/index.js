'use strict';

exports.quote = require('./quote');
exports.parse = require('./parse');
