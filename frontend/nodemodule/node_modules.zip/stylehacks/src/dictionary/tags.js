'use strict';
const BODY = 'body';
const HTML = 'html';

module.exports = { BODY, HTML };
