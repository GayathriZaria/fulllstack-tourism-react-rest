export declare const initTitle: (title: string) => void;
export declare const initText: (text: string) => void;
